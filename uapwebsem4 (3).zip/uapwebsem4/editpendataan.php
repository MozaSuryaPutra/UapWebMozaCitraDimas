<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idpendataan = $_POST['idpendataan'];
    $nisn = $_POST['nisn'];
    $idjur = $_POST['idjur'];
    

    
    

    $insertQuery = "UPDATE `pendataan` SET `nisn`='$nisn',`idjur`='$idjur' WHERE idpendataan = '$idpendataan'";
    if (mysqli_query($conn, $insertQuery)) {
        header("location: pendataan.php");
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        echo "<script>window.location.href = 'pendataan.php';</script>";
        exit();
    }
}
?>