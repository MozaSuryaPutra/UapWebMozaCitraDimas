<?php
$host = "localhost"; 
$user = "root"; 
$password = ""; 
$dbname = "uapweb"; 

$conn = new mysqli($host, $user, $password, $dbname);
?>