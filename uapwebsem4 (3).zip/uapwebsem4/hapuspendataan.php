<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php'; 

if (isset($_GET['id'])) {
    
    $idpendataan = $_GET['id'];
    

    $insertQuery = "DELETE FROM `pendataan` WHERE idpendataan = '$idpendataan'";
    if (mysqli_query($conn, $insertQuery)) {
        header("location: pendataan.php");
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        echo "<script>window.location.href = 'pendataan.php';</script>";
        exit();
    }
}
?>