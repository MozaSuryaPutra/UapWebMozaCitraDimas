<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}

require 'function.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Data Universitas - Manajemen Universitas</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.html">Pendataan Eligible Siswa</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                   </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
    <div class="d-flex justify-content-center">
        <form action="" method="post">
            <button type="submit" name="logout" class="btn btn-primary" style="width: 100px; height: 50px;">Logout</button>
        </form>
    </div>
</ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Dash</div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                        
                            <div class="sb-sidenav-menu-heading">Manage</div>
                            <a class="nav-link" href="siswa.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Siswa
                            </a>
                            
                            <a class="nav-link" href="univ.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Univ
                            </a>
                            <a class="nav-link" href="fakultas.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Fakultas
                            </a>
                            <a class="nav-link" href="jurusan.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Jurusan
                            </a>
                            <a class="nav-link" href="pendataan.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Pendataan Siswa
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Masuk sebagai:</div>
                        Admin
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Data Universitas</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Menu</li>
                        </ol>
                        <div class="card mb-4"></div>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalTambahUniv">+ Tambah Universitas</button>

                      


                        <br><br>
                        <div class="card mb-4">
                            <div class="card-body">
                            <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Id Universitas</th>
                                            <th>Nama Universitas</th>
                                            <th>Alamat</th>
                                            <th>Website</th>
                                            <th>Akreditasi</th>
                                            <th>Peringkat</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $ambildatauniv = mysqli_query($conn, "SELECT * FROM univ");
                                    while ($data = mysqli_fetch_array($ambildatauniv)) {
                                        $iduniv = $data['iduniv'];
                                        $namauniv = $data['namauniv'];
                                        $alamat = $data['alamat'];
                                        $website = $data['website'];
                                        $akreditasi = $data['akreditasi'];
                                        $peringkat = $data['peringkat'];
                                    ?>
                                        <tr>
                                            <td><?= $iduniv; ?></td>
                                            <td><?= $namauniv; ?></td>
                                            <td><?= $alamat; ?></td>
                                            <td><?= $website; ?></td>
                                            <td><?= $akreditasi; ?></td>
                                            <td><?= $peringkat; ?></td>
                                            <td>
                                                <a href=# class="btn btn-primary" data-toggle="modal" data-target="#modalEditUniv<?=$iduniv?>">Edit</a>
                                                <a href="hapusuniv.php?id=<?= $iduniv; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data universitas ini?');">Hapus</a>
                                            </td>
                                        </tr>

                                        <!-- Modal Edit -->
                                        <div class="modal fade bd-example-modal-lg" id="modalEditUniv<?=$iduniv?>" tabindex="-1" role="dialog" aria-labelledby="modalEditUnivLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalEditUnivLabel">Edit Data Siswa</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form class="details-form" method="post" action="edituniv.php" id="resepForm">
                                                            
                                                            <div class="form-group">
                                                            <label for="nisn" class="col-form-label">Id Universitas :</label>
                                                            <input type="text" class="form-control" value="<?= $data['iduniv'] ?>" name="iduniv" id="iduniv" placeholder="Masukan ID Universitas" readonly>
                                                        </div>

                                                        <div class="form-group">
                                                        <label for="nama" class="col-form-label">Nama Universitas :</label>
                                                        <input type="text" placeholder="Masukan Nama Universitas" class="form-control" value="<?= $data['namauniv'] ?>" name="namauniv" id="namauniv" required>
                                                        </div>
                                                        
                                                        
                                                        <div class="form-group">
                                                            <label for="deksripsi" class="col-form-label">Alamat :</label>
                                                            <input type="text" placeholder="Masukan Alamat" class="form-control" value="<?= $data['alamat'] ?>" name="alamat" id="alamat" required>
                                                        
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="deksripsi" class="col-form-label">Website :</label>
                                                            <input type="text" placeholder="Masukan Website" class="form-control" value="<?= $data['website'] ?>" name="website" id="website" required>
                                                        
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="deksripsi" class="col-form-label">Akreditasi :</label>
                                                            <input type="text" placeholder="Masukan Akreditasi" class="form-control" value="<?= $data['akreditasi'] ?>" name="akreditasi" id="akreditasi" required>
                                                        
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="deksripsi" class="col-form-label">Peringkat :</label>
                                                            <input type="text" placeholder="Masukan Peringkat" class="form-control" value="<?= $data['peringkat'] ?>" name="peringkat" id="peringkat" required>
                                                        
                                                        </div>
                                                            
                                                            
                                                     
                                                    </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">Ubah</button>
                                                </div>
                                                </form>
                                            </div>
                                            </div>
                                        </div>

                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>

    
<!-- Modal Tambah -->
<div class="modal fade bd-example-modal-lg" id="modalTambahUniv" tabindex="-1" role="dialog" aria-labelledby="modalTambahUnivLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <div class="modal-header">
          <h4 class="modal-title">Tambah Data Universitas</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <div class="modal-body">
            <form class="details-form" method="post" action="tambahuniv.php" id="resepForm">
                <div class="form-group">
                    <label for="nisn" class="col-form-label">Id Universitas :</label>
                    <input type="text" class="form-control" name="iduniv" id="iduniv" placeholder="Masukan ID Universitas" required>
                </div>

                <div class="form-group">
                  <label for="nama" class="col-form-label">Nama Universitas :</label>
                  <input type="text" placeholder="Masukan Nama Universitas" class="form-control" name="namauniv" id="namauniv" required>
                </div>
                
                
                <div class="form-group">
                    <label for="deksripsi" class="col-form-label">Alamat :</label>
                    <input type="text" placeholder="Masukan Alamat" class="form-control" name="alamat" id="alamat" required>
                 
                </div>

                <div class="form-group">
                    <label for="deksripsi" class="col-form-label">Website :</label>
                    <input type="text" placeholder="Masukan Website" class="form-control" name="website" id="website" required>
                 
                </div>
                <div class="form-group">
                    <label for="deksripsi" class="col-form-label">Akreditasi :</label>
                    <input type="text" placeholder="Masukan Akreditasi" class="form-control" name="akreditasi" id="akreditasi" required>
                 
                </div>
                <div class="form-group">
                    <label for="deksripsi" class="col-form-label">Peringkat :</label>
                    <input type="text" placeholder="Masukan Peringkat" class="form-control" name="peringkat" id="peringkat" required>
                 
                </div>
                
        </div>
        
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Simpan</button>
           
        </div>
        </form>
      </div>
    </div>
  </div>

</html>



