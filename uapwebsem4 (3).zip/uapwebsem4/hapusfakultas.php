<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $hapus = mysqli_query($conn, "DELETE FROM fakultas WHERE `idfak` = '$id'");

    if ($hapus) {
        echo "<script>alert('Menu berhasil dihapus');</script>";
        header("Location: fakultas.php");
        exit();
    } else {
        echo "<script>alert('Gagal menghapus menu');</script>";
        header("Location: fakultas.php");
        exit();
    }
} else {
    header("Location: fakultas.php");
    exit();
}
?>
