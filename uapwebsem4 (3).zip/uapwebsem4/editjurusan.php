<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $idjur = $_POST['idjur'];
    $namajur = $_POST['namajur'];
    $akreditasijur = $_POST['akreditasijur'];
    $dayatampung = $_POST['dayatampung'];
    $idfak = $_POST['idfak'];

    
    

    $insertQuery = "UPDATE `jurusan` SET `namajur`='$namajur',`akreditasijur`='$akreditasijur',`dayatampung`=$dayatampung,`idfak`='$idfak' WHERE idjur = '$idjur'";
    if (mysqli_query($conn, $insertQuery)) {
        header("location: jurusan.php");
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        echo "<script>window.location.href = 'jurusan.php';</script>";
        exit();
    }
}
?>