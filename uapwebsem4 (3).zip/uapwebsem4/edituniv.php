<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $iduniv = $_POST['iduniv'];
    $namauniv = $_POST['namauniv'];
    $alamat = $_POST['alamat'];
    $website = $_POST['website'];
    $akreditasi = $_POST['akreditasi'];
    $peringkat = $_POST['peringkat'];
    

    $insertQuery = "UPDATE `univ` SET `namauniv`='$namauniv',`alamat`='$alamat',`website`='$website',`akreditasi`='$akreditasi',`peringkat`='$peringkat' WHERE iduniv = '$iduniv'";
    if (mysqli_query($conn, $insertQuery)) {
        header("location: univ.php");
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        echo "<script>window.location.href = 'univ.php';</script>";
        exit();
    }
}
?>