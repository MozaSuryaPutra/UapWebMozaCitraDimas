<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    // Clear all session variables
    session_unset();

    // Destroy the session
    session_destroy();

    // Redirect to login page
    header("Location: index.php");
    exit;
}
require 'function.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Data Menu - Manajemen Restoran</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.php">Manajemen Restoran</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Cari..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="login.php">Keluar</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Dash</div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                        
                            <div class="sb-sidenav-menu-heading">Manage</div>
                            <a class="nav-link" href="tables.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Menu
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Masuk sebagai :</div>
                        Admin
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Data Menu</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Menu</li>
                        </ol>
                        <div class="card mb-4"></div>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalTambahMenu">+ Tambah Menu</button>

                        <br><br>
                        <div class="card mb-4">
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>ID Menu</th>
                                            <th>Nama Menu</th>
                                            <th>Kategori</th>
                                            <th>Harga</th>
                                            <th>Deskripsi</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php

                                    $ambildatamenu = mysqli_query($conn, "SELECT * FROM menu_cafe");
                                    while ($data = mysqli_fetch_array($ambildatamenu)) {
                                        $id_menu = $data['id_menu'];
                                        $nama_menu = $data['nama_menu'];
                                        $kategori = $data['kategori'];
                                        $harga = $data['harga'];
                                        $deskripsi = $data['deskripsi'];
                                        
                                    ?>
                                        <tr>
                                            <td><?= $id_menu; ?></td>
                                            <td><?= $nama_menu; ?></td>
                                            <td><?= $kategori; ?></td>
                                            <td><?= $harga; ?></td>
                                            <td><?= $deskripsi; ?></td>
                                            <td>
                                                <a href=# class="btn btn-primary" data-toggle="modal" data-target="#modalEditMenu<?=$id_menu?>">Edit</a>
                                                <a href="hapus_menu.php?id_menu=<?= $id_menu; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">Hapus</a>
                                            </td>
                                        </tr>

                                        <!-- Modal Edit -->
                                        <div class="modal fade bd-example-modal-lg" id="modalEditMenu<?=$id_menu?>" tabindex="-1" role="dialog" aria-labelledby="modalEditMenuLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalEditMenuLabel">Edit Menu</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form class="details-form" method="post" action="edit_menu.php" id="resepForm">
                                                            <div class="form-group">
                                                                <label for="id_menu" class="col-form-label">ID Menu :</label>
                                                                <input type="text" class="form-control" value="<?= $data['id_menu'] ?>" name="id_menu" placeholder="Masukan id menu.." required>
                                                            </div>

                                                            <div class="form-group">
                                                            <label for="nama_menu" class="col-form-label">Nama Menu :</label>
                                                            <input type="text" placeholder="Masukan Nama Menu.." class="form-control" value="<?= $data['nama_menu'] ?>" name="nama_menu" required>
                                                            </div>
                                                            
                                                            <div class="form-group">
                                                                <label for="kategori" class="col-form-label">Kategori :</label>
                                                                <select class="form-control" name="kategori" id="kategori" required>
                                                                    <option value="Pilih Kategori">Pilih Kategori</option>
                                                                    <option value="Minuman"<?php if($data['kategori'] == 'Minuman') echo ' selected'; ?>>Minuman</option>
                                                                    <option value="Makanan Ringan"<?php if($data['kategori'] == 'Makanan Ringan') echo ' selected'; ?>>Makanan Ringan</option>
                                                                    <option value="Makanan Berat"<?php if($data['kategori'] == 'Makanan Berat') echo ' selected'; ?>>Makanan Berat</option>
                                                                    <option value="Makanan Penutup"<?php if($data['kategori'] == 'Makanan Penutup') echo ' selected'; ?>>Makanan Penutup</option>
                                                                    <option value="Camilan"<?php if($data['kategori'] == 'Camilan') echo ' selected'; ?>>Camilan</option>
                                                                </select>
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="harga" class="col-form-label">Harga :</label>
                                                                <input type="text" placeholder="Masukan Harga Menu.."  value="<?= $data['harga'] ?>" class="form-control" name="harga" required>
                                                            </div>
                                                            
                                                            <div class="form-group">
                                                                <label for="deksripsi" class="col-form-label">Deskripsi Menu :</label>
                                                                <textarea class="form-control" placeholder="Deksripsikan Menu..." name="deskripsi" required><?= $data['deskripsi'] ?></textarea>
                                                            </div>
                                                    </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">Ubah</button>
                                                </div>
                                                </form>
                                            </div>
                                            </div>
                                        </div>

                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>

    
<!-- Modal Tambah -->
<div class="modal fade bd-example-modal-lg" id="modalTambahMenu" tabindex="-1" role="dialog" aria-labelledby="modalTambahMenuLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <div class="modal-header">
          <h4 class="modal-title">Tambah Menu</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <div class="modal-body">
            <form class="details-form" method="post" action="tambah_menu.php" id="resepForm">
                <div class="form-group">
                    <label for="id_menu" class="col-form-label">ID Menu :</label>
                    <input type="text" class="form-control" name="id_menu" id="id_menu" placeholder="Masukan id menu.." required>
                </div>

                <div class="form-group">
                  <label for="nama_menu" class="col-form-label">Nama Menu :</label>
                  <input type="text" placeholder="Masukan Nama Menu.." class="form-control" name="nama_menu" id="nama_menu" required>
                </div>
                
                <div class="form-group">
                    <label for="RS Dituju" class="col-form-label">Kategori :</label>
                    <select class="form-control" name="kategori" id="kategori" required>
                        <option selected>Pilih Kategori</option>
                        <option value="Minuman">Minuman</option>
                        <option value="Makanan Ringan">Makanan Ringan</option>
                        <option value="Makanan Berat">Makanan Berat</option>
                        <option value="Makanan Penutup">Makanan Penutup</option>
                        <option value="Camilan">Camilan</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="harga" class="col-form-label">Harga :</label>
                    <input type="text" placeholder="Masukan Harga Menu.." class="form-control" name="harga" id="harga" required>
                  </div>
                  
                <div class="form-group">
                    <label for="deksripsi" class="col-form-label">Deskripsi Menu :</label>
                    <textarea class="form-control" placeholder="Tindakan yang telah dilakukan.." 
                    name="deskripsi" id="deskripsi" required></textarea>
                </div>
        </div>
        
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-secondary" onclick="resetForm()">Reset</button>
        </div>
        </form>
      </div>
    </div>
  </div>

</html>

<script>
    function resetForm() {
        document.getElementById("resepForm").reset();
    }
</script>

