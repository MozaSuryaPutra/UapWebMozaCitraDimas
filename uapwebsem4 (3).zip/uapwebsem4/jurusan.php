<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Data Jurusan - Manajemen Jurusan</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.html">Pendataan Eligible Siswa</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
    <div class="d-flex justify-content-center">
        <form action="" method="post">
            <button type="submit" name="logout" class="btn btn-primary" style="width: 100px; height: 50px;">Logout</button>
        </form>
    </div>
</ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Dash</div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                        
                            <div class="sb-sidenav-menu-heading">Manage</div>
                            <a class="nav-link" href="siswa.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Siswa
                            </a>
                            
                            <a class="nav-link" href="univ.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Univ
                            </a>
                            <a class="nav-link" href="fakultas.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Fakultas
                            </a>
                            <a class="nav-link" href="jurusan.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Jurusan
                            </a>
                            <a class="nav-link" href="pendataan.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Pendataan Siswa
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Masuk sebagai:</div>
                        Admin
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Data Jurusan</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Menu</li>
                        </ol>
                        <div class="card mb-4"></div>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalTambahJurusan">+ Tambah Jurusan</button>

                      


                        <br><br>
                        <div class="card mb-4">
                            <div class="card-body">
                            <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Id Jurusan</th>
                                            <th>Nama Jurusan</th>
                                            <th>Asal Fakultas</th>
                                            <th>Asal Universitas</th>
                                            
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $ambildatajurusan = mysqli_query($conn, "select * from univ join fakultas on fakultas.iduniv = univ.iduniv join jurusan on jurusan.idfak = fakultas.idfak");
                                    while ($data = mysqli_fetch_array($ambildatajurusan)) {
                                        $idjur =  $data['idjur'];
                                        $namajur = $data['namajur'];
                                        $namafak = $data['namafak'];
                                        $namauniv = $data['namauniv'];
                                        $iduniv_jurusan = $data['iduniv'];
                                        $idfak_jurusan = $data['idfak'];
                                        
                                    ?>
                                        <tr>
                                            <td><?= $idjur; ?></td>
                                            <td><?= $namajur; ?></td>
                                            <td><?= $namafak; ?></td>
                                            <td><?= $namauniv; ?></td>
                                            <td>
                                                <a href=# class="btn btn-primary" data-toggle="modal" data-target="#modalEditJurusan<?=$idjur?>">Edit</a>
                                                <a href="hapusjurusan.php?id=<?= $idjur; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data jurusan ini?');">Hapus</a>
                                            </td>
                                        </tr>

                                        <!-- Modal Edit -->
                                        <div class="modal fade bd-example-modal-lg" id="modalEditJurusan<?=$idjur?>" tabindex="-1" role="dialog" aria-labelledby="modalEditFakultasLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalEditUnivLabel">Edit Data Jurusan</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form class="details-form" method="POST" action="editjurusan.php" id="resepForm">
                                                            
                                                        <div class="form-group">
                                                            <label for="nisn" class="col-form-label">Id Jurusan :</label>
                                                            <input type="text" class="form-control" value="<?= $data['idjur'] ?>" name="idjur" id="idjur" placeholder="Masukan ID Jurusan" readonly>
                                                        </div>

                                                        <div class="form-group">
                                                        <label for="nama" class="col-form-label">Nama Jurusan :</label>
                                                        <input type="text" placeholder="Masukan Nama Jurusan" class="form-control" value="<?= $data['namajur'] ?>" name="namajur" id="namajur" required>
                                                        </div>

                                                        <div class="form-group">
                                                        <label for="nama" class="col-form-label">Akreditasi :</label>
                                                        <input type="text" placeholder="Masukan Akreditasi" class="form-control" value="<?= $data['akreditasijur'] ?>" name="akreditasijur" id="akreditasijur" required>
                                                        </div>

                                                        <div class="form-group">
                                                        <label for="nama" class="col-form-label">Daya Tampung :</label>
                                                        <input type="number" placeholder="Masukan Daya Tampung" class="form-control" value="<?= $data['dayatampung'] ?>" name="dayatampung" id="dayatampung" required>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                    <label for="iduniv" class="col-form-label">Asal Universitas:</label>
                                                    <select class="form-control" name="idfak" id="idfak" required>
                                                        <?php
                                                        // Mengambil data universitas dari database
                                                        $ambildatafakultas = mysqli_query($conn, "select * from fakultas join univ on univ.iduniv = fakultas.iduniv");
                                                        while ($data = mysqli_fetch_array($ambildatafakultas)) {
                                                            $idfak = $data['idfak'];
                                                            $namafak = $data['namafak'];
                                                            $namauniv = $data['namauniv'];
                                                            // Menentukan universitas yang sesuai dengan fakultas yang sedang diedit
                                                            $selected = ($idfak == $idfak_jurusan) ? "selected" : "";
                                                            echo "<option value='$idfak' $selected>$namafak,$namauniv</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                     </div>
                                                     </div>
                                                        
                                                            
                                                            
                                                     
                                                    
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">Ubah</button>
                                                </div>
                                                </form>
                                            </div>
                                            </div>
                                        </div>

                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>

    
<!-- Modal Tambah -->
<div class="modal fade bd-example-modal-lg" id="modalTambahJurusan" tabindex="-1" role="dialog" aria-labelledby="modalTambahJurusanLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <div class="modal-header">
          <h4 class="modal-title">Tambah Data Jurusan</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <div class="modal-body">
            <form class="details-form" method="post" action="tambahjurusan.php" id="resepForm">
            <div class="form-group">
                                                            <label for="nisn" class="col-form-label">Id Jurusan :</label>
                                                            <input type="text" class="form-control" name="idjur" id="idjur" placeholder="Masukan ID Jurusan" required>
                                                        </div>

                                                        <div class="form-group">
                                                        <label for="nama" class="col-form-label">Nama Jurusan :</label>
                                                        <input type="text" placeholder="Masukan Nama Jurusan" class="form-control"  name="namajur" id="namajur" required>
                                                        </div>

                                                        <div class="form-group">
                                                        <label for="nama" class="col-form-label">Akreditasi :</label>
                                                        <input type="text" placeholder="Masukan Akreditasi" class="form-control"  name="akreditasijur" id="akreditasijur" required>
                                                        </div>

                                                        <div class="form-group">
                                                        <label for="nama" class="col-form-label">Daya Tampung :</label>
                                                        <input type="number" placeholder="Masukan Daya Tampung" class="form-control" name="dayatampung" id="dayatampung" required>
                                                        </div>
                
                                                        <div class="form-group">
                                                    <label for="iduniv" class="col-form-label">Asal Universitas:</label>
                                                    <select class="form-control" name="idfak" id="idfak" required>
                                                        <?php
                                                        // Mengambil data universitas dari database
                                                        $ambildatafakultas = mysqli_query($conn, "select * from fakultas join univ on univ.iduniv = fakultas.iduniv");
                                                        while ($data = mysqli_fetch_array($ambildatafakultas)) {
                                                            $idfak = $data['idfak'];
                                                            $namafak = $data['namafak'];
                                                            $namauniv = $data['namauniv'];
                                                            
                                                            echo "<option value='$idfak' >$namafak,$namauniv</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                     </div>
                
                

                
                
        </div>
        
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Simpan</button>
           
        </div>
        </form>
      </div>
    </div>
  </div>

</html>



