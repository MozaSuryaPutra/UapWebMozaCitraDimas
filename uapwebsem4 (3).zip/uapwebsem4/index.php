<?php
require 'function.php';
session_start();

if(isset($_SESSION["login"])){
    header("Location: dashboard.php");
    
    }

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $pas = $_POST['password'];

    $cekdatabase = mysqli_query($conn,"SELECT * FROM admin where username='$username' and password = '$pas' ");
    $hitung = mysqli_num_rows($cekdatabase);

    if($hitung>0){
        $_SESSION['login'] ='True';
        header ('location:dashboard.php');
    }else{
        header ('location:index.php');
    };

};
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Restoran</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
                        url('https://i.pinimg.com/564x/b9/1d/95/b91d9545bfa00297af16d5674226a4cc.jpg') no-repeat center center/cover;
        }
        .container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }
        .header h1 {
            margin: 0;
            color: #333;
            font-size: 24px;
        }
        .header p {
            color: #777;
            margin-top: 5px;
        }
        .login-form {
            margin-top: 20px;
        }
        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: calc(100% - 40px);
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
            transition: border-color 0.3s;
        }
        .login-form input[type="text"]:focus,
        .login-form input[type="password"]:focus {
            border-color: #007BFF;
        }
        .login-form button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007BFF;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .login-form button:hover {
            background-color: #0056b3;
        }
        .footer {
            margin-top: 20px;
            color: #777;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Pendataan Eligible</h1>
            <p>Silakan login untuk mengakses sistem</p>
        </div>
        <!-- Form login -->
        <div class="login-form">
            <form method="post" action="">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="login">Login</button>
            </form>
        </div>
        <div class="footer">
            &copy; 2024 SMA 7 BANDAR LAMPUNG. All rights reserved.
        </div>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            event.preventDefault();
            alert('Login Berhasil!');
        });
    </script>
</body>
</html>
