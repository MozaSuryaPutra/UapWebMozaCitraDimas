<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $iduniv = $_POST['iduniv'];
    $namafak = $_POST['namafak'];
    $idfak = $_POST['idfak'];
    

    $insertQuery = "UPDATE `fakultas` SET `namafak`='$namafak',`iduniv`='$iduniv' WHERE idfak = '$idfak'";
    if (mysqli_query($conn, $insertQuery)) {
        header("location: fakultas.php");
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        echo "<script>window.location.href = 'fakultas.php';</script>";
        exit();
    }
}
?>