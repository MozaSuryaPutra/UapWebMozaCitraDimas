<?php
session_start();
require 'function.php';


if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}



if(isset($_POST['logout'])) {
    session_unset();   
    session_destroy();  
    header("Location: index.php");
    exit;
}

$sql3 = "SELECT COUNT(*) AS total FROM siswa";
$result3 = $conn->query($sql3);


$total_students = 0;
if ($result3->num_rows > 0) {
    $row3 = $result3->fetch_assoc();
    $total_students = $row3['total'];
}

$sql4 = "SELECT COUNT(*) AS total FROM univ";
$result4 = $conn->query($sql4);

// Fetch the result
$total_univ = 0;
if ($result4->num_rows > 0) {
    $row4 = $result4->fetch_assoc();
    $total_univ = $row4['total'];
}

$sql5 = "SELECT COUNT(*) AS total FROM fakultas";
$result5 = $conn->query($sql5);


$total_fak = 0;
if ($result5->num_rows > 0) {
    $row5 = $result5->fetch_assoc();
    $total_fak = $row5['total'];
}

$sql6 = "SELECT COUNT(*) AS total FROM jurusan";
$result6 = $conn->query($sql6);


$total_jur = 0;
if ($result6->num_rows > 0) {
    $row6 = $result6->fetch_assoc();
    $total_jur = $row6['total'];
}

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard  - Manajemen eligible</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="dashboard.html">Pendataan Eligible Siswa</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                   </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
    <div class="d-flex justify-content-center">
        <form action="" method="post">
            <button type="submit" name="logout" class="btn btn-primary" style="width: 100px; height: 50px;">Logout</button>
        </form>
    </div>
</ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Dash</div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                        
                            <div class="sb-sidenav-menu-heading">Manage</div>
                            <a class="nav-link" href="siswa.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Data Siswa
                            </a>
                            
                            <a class="nav-link" href="univ.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Univ
                            </a>
                            <a class="nav-link" href="fakultas.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Fakultas
                            </a>
                            <a class="nav-link" href="jurusan.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Jurusan
                            </a>
                            <a class="nav-link" href="pendataan.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Pendataan Siswa
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Masuk sebagai:</div>
                        Admin
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Selamat Datang, Admin!</li>
                        </ol>

                        <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">Total Mahasiswa : <?php echo $total_students; ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="siswa.php">Lihat Detail</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-warning text-white mb-4">
                        <div class="card-body">Total Universitas : <?php echo $total_univ; ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="univ.php">Lihat Detail</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-success text-white mb-4">
                        <div class="card-body">Total Fakultas : <?php echo $total_fak; ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="fakultas.php">Lihat Detail</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-danger text-white mb-4">
                        <div class="card-body">Total Jurusan : <?php echo $total_jur; ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="jurusan.php">Lihat Detail</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Daftar Siswa Eligible dan Non - Eligible</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Nisn</th>
                                    <th>Nama</th>
                                    <th>Kelas</th>
                                    <th>Nilai Akhir</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $ambildata = mysqli_query($conn, "WITH ranked_students AS (
                                SELECT
                                    *,
                                    ROW_NUMBER() OVER (ORDER BY nilaiakhir DESC) AS row_num,
                                    COUNT(*) OVER () AS total_count
                                FROM
                                    siswa
                            ),
                            eligible_students AS (
                                SELECT
                                    *,
                                    total_count * 0.4 AS eligible_threshold
                                FROM
                                    ranked_students
                            )
                            SELECT
                                *,
                                CASE
                                    WHEN row_num <= eligible_threshold THEN 'eligible'
                                    ELSE 'non eligible'
                                END AS status
                            FROM
                                eligible_students
                            ORDER BY
                                nilaiakhir DESC;
                            ");
                            while ($data = mysqli_fetch_array($ambildata)) {
                                $nisn = $data['nisn'];
                                $nama = $data['nama'];
                                $kelas = $data['kelas'];
                                $nilaiakhir = $data['nilaiakhir'];
                                $status = $data['status'];
                                
                            ?>
                                <tr>
                                    <td><?= $nisn; ?></td>
                                    <td><?= $nama; ?></td>
                                    <td><?= $kelas; ?></td>
                                    <td><?= $nilaiakhir; ?></td>
                                    <td><?= $status; ?></td>
                            </tbody>
                            <?php
                            }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Manajemen Restoran 2024</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
