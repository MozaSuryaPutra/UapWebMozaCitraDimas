<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php';

if (isset($_GET['nisn'])) {
    $nisn = $_GET['nisn'];

    $hapus = mysqli_query($conn, "DELETE FROM siswa WHERE `nisn` = '$nisn'");

    if ($hapus) {
        echo "<script>alert('Menu berhasil dihapus');</script>";
        header("Location: siswa.php");
        exit();
    } else {
        echo "<script>alert('Gagal menghapus menu');</script>";
        header("Location: siswa.php");
        exit();
    }
} else {
    header("Location: siswa.php");
    exit();
}
?>
