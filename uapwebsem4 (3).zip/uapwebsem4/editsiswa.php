<?php
session_start();
if (!isset($_SESSION['login']) || $_SESSION['login'] !== 'True') {
    header("Location: index.php");
    exit;
}


if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
require 'function.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $nisn = $_POST['nisn'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $bing = $_POST['bing'];
    $bindo = $_POST['bindo'];
    $mtk = $_POST['mtk'];
    $kimia = $_POST['kimia'];
    $fisika = $_POST['fisika'];
    $biologi = $_POST['biologi'];
    $tanggallahir = $_POST['tanggallahir'];
    

    $insertQuery = "UPDATE `siswa` SET `nisn`='$nisn',`nama`='$nama',`kelas`='$kelas',`tanggallahir`='$tanggallahir',`bing`=$bing,`bindo`=$bindo,`mtk`=$mtk,`kimia`=$kimia,`fisika`=$fisika,`biologi`=$biologi WHERE nisn = '$nisn'";
    if (mysqli_query($conn, $insertQuery)) {
        header("location: siswa.php");
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        echo "<script>window.location.href = 'siswa.php';</script>";
        exit();
    }
}
?>